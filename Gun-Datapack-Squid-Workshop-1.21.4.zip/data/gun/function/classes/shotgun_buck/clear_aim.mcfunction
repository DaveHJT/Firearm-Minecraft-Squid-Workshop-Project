effect clear @s minecraft:slowness
item replace entity @s weapon.mainhand with minecraft:carrot_on_a_stick[custom_model_data={strings:["double_barrel_shotgun"]}, item_name='{"text":"double barrel shotgun - buck"}', custom_data={gun:1b,shotgun:1b,buck:1b}]

