effect give @s minecraft:slowness 1 0 true
scoreboard players add @s aim 1
execute if score @s aim matches 2 run item replace entity @s weapon.mainhand with minecraft:carrot_on_a_stick[custom_model_data={strings:["double_barrel_shotgun_copper_aim"]}, item_name='{"text":"double barrel shotgun - slug"}', custom_data={gun:1b,shotgun:1b,slug:1b}]


#remove recoil
execute as @a[scores={recoil=12..}] run scoreboard players remove @s recoil 1