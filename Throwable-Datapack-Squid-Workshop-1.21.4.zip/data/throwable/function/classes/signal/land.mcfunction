summon item ~ ~ ~ {Item:{id:"minecraft:snowball",Count:1b,components:{"minecraft:custom_data":{custom_model_data:{strings:["signal"]}, item_name:'{"text":"signal flare"}'}}},PickupDelay:32767s,Tags:["signal_effect","effect"]}

effect give @e[tag=signal_effect,limit=1,sort=nearest] slow_falling 10000 10 true

scoreboard players operation @e[tag=effect,limit=1,sort=nearest] throwable_life = @s throwable_life

scoreboard players operation @e[tag=effect,limit=1,sort=nearest] UID = @s UID

playsound minecraft:gun/thrower/flash_hit player @a ~ ~ ~ 2 1

kill @s